import React, { useState, useEffect } from "react";

const dummyTiles = [
  ...Array.from({ length: 13 }, (_, i) => i + 1),
  "çek",
];

const generateHand = () => {
  const tiles = [...dummyTiles];
  for (let i = tiles.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [tiles[i], tiles[j]] = [tiles[j], tiles[i]];
  }
  return tiles.slice(0, 14);
};

const PlayerHand = ({ hand, name }) => (
  <div className="p-2 bg-white rounded shadow w-full">
    <div className="font-bold mb-1">{name}</div>
    <div className="flex flex-wrap gap-1">
      {hand.map((tile, i) => (
        <div key={i} className="px-2 py-1 bg-yellow-100 rounded border">
          {tile}
        </div>
      ))}
    </div>
  </div>
);

export default function OkeyDemo() {
  const [players, setPlayers] = useState([
    { name: "Sen", hand: [] },
    { name: "Bot 1", hand: [] },
    { name: "Bot 2", hand: [] },
    { name: "Bot 3", hand: [] },
  ]);

  useEffect(() => {
    const newHands = players.map((p) => ({ ...p, hand: generateHand() }));
    setPlayers(newHands);
  }, []);

  return (
    <div className="p-4 bg-green-200 min-h-screen space-y-4">
      <h1 className="text-2xl font-bold text-center">Okey Demo (Botlu)</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {players.map((player, index) => (
          <PlayerHand key={index} name={player.name} hand={player.hand} />
        ))}
      </div>
    </div>
  );
}
